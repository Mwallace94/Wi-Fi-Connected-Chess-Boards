from django.http import HttpRequest

#authenticateUser(username, password) #a db function

#checks if there is a user logged into the session
#note that this returns True/False not a falsy object
def isAuthenticated(request):
    if request.session.get('_ujs_user', ''):
        return True
    else:
        return False

#logs in the user identified by username
def loginUser(request, username):
    request.session['_ujs_user'] = username

#logs out the currently logged in user
def logoutUser(request):
    try:
        del request.session['_ujs_user']
    except KeyError:
        pass
    request.session.flush()

#gets the username of the user that is currently logged in
def getLoggedUsername(request):
    return request.session.get('_ujs_user', '')
