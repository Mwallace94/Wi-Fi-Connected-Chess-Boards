from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpRequest
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from Queries.userqueries import *
from uconnjobsearch.views import home
from accounts.auth import isAuthenticated
from accounts.auth import loginUser
from accounts.auth import logoutUser
from accounts.auth import getLoggedUsername


@sensitive_post_parameters()
@csrf_protect
@never_cache
def login(request):
    #if the user is already logged in, redirect to home
    if isAuthenticated(request):
        return redirect('uconnjobsearch:home')
    else:
        try:
            #get the login info from the POST request
            #check that they sent the data, and that the fields are not empty
            user = request.POST['user']
            passwd = request.POST['pass']
            if not user or not passwd:
                raise KeyError
        except KeyError:
            #one of our post keys was not found (or was empty)
            #this either means they did not fill out the form, or we got a get request.
            errorText = "Please fill out all of the required fields to login."
            return home(request, {'loginError':errorText})
            #return render(request, 'uconnjobsearch/home.html', {'loginError': errorText})
            #return redirect('uconnjobsearch.views.home', extras={'loginError':errorText})
        else:
            #the user filled out both fields the form
            #check if the supplied password matches what we have for the given username
            if authenticateUser(user, passwd):
                #if so, log that user in with the current session
                loginUser(request, user);
                #generate the URL of the homescreen, redirect the user to it
                return HttpResponseRedirect(reverse('uconnjobsearch:home'))
            else:
                errorText = "Incorrect username or password. Try again."
                return home(request, {'loginError':errorText})
                #return render(request, 'uconnjobsearch/home.html', {'loginError': errorText})

@sensitive_post_parameters()
@csrf_protect
@never_cache
def register(request):
    if isAuthenticated(request):
        return HttpResponseRedirect(reverse('uconnjobsearch:home'))
    else:
        try:
            #make sure all the registration info checks out
            reqposts = ['name', 'pass', 'pass2', 'fname', 'lname', 'street1', 'city', 'state', \
                         'zip', 'email', 'phone']
            optposts = ['street2, fax, cell, homepage']
            data = request.POST.dict()
            #if one of the required post fields was blank, raise an error
            for val in reqposts:
                if not data[val]:
                    raise KeyError("%s key had an empty value" % val)
            #if the passwords did not match, return an error
            if data['pass'] != data['pass2']:
                passMatchErr = "The entered passwords did not match."
                return render(request, 'uconnjobsearch/home.html', {'regError':passMatchErr})
        except KeyError:
            #the user didn't fill something out..
            noEntryErr = "Please fill out all of the required fields to register."
            return render(request, 'uconnjobsearch/home.html', {'regError': noEntryErr})
        else:
            #the user filled out all required fields successfully. Add them to the db
            #i messed up when specifying what the names of the post variables will be and
            #don't want to change the spec after releasing it to the group, so here we go...
            userinfo = {'UName':data['name'], 'UPasswd':data['pass'], 'UFName':data['fname'],
                        'ULName':data['lname'], 'UStreet1':data['street1'], 'UStreet2':data['street2'],
                        'UCity':data['city'], 'StateID':data['state'], 'Zipcode':data['zip'],
                        'UEmail':data['email'], 'UPhone':data['phone'], 'UFax':data['fax'],
                        'UCell':data['cell'], 'UHomePage':data['homepage'], 'UStatusID':""}
            registerUser(userinfo) #a function from our uconnjobsearch/sqlfuncs.py file
            return HttpResponseRedirect(reverse('uconnjobsearch:home'))
            

def logout(request):
    logoutUser(request)
    return HttpResponseRedirect(reverse('uconnjobsearch:home'))


