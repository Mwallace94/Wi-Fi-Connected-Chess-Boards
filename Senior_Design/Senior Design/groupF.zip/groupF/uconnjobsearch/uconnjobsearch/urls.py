from django.conf.urls import include
from django.conf.urls import url
#from . import views
from uconnjobsearch import views

#since in the specs document i handed out had namespaced url's, 
#i'm going to stick with that. Otherwise, I wouldn't have namespaced 
#the urls in the base project
nsurl = [
    url(r'^$', views.home, name='home'),
    url(r'^dashboard/$', views.dashboard, name='dashboard'),
    url(r'^usersettings/$', views.edituser, name='edituser'),
    url(r'^searchjobs/', views.searchjobs, name='searchjobs'),
    url(r'^viewresume/(?P<resumeID>[0-9]+)$', views.viewresume, name='viewresume'),
    url(r'^viewjob/(?P<jobID>[0-9]+)$', views.viewjob, name='viewjob'),
    url(r'^changejob/$', views.changejob, name='changejob'),
    url(r'^postjob/$', views.postjob, name='postjob'),
    url(r'^editjobattrs/$', views.editjobattrs, name='editattrs'),
    url(r'^addresume/$', views.addresume, name='addresume'),
    url(r'^editresume/(?P<resumeID>[0-9]+)$', views.editresume, name='editresume'),
    #url(r'^resumebuilder/$', views.resumebuilder, name='resumebuilder'),
    url(r'^adminpanel/$', views.adminpanel, name='adminpanel'),
]

urlpatterns = [
    url(r'^accounts/', include('accounts.urls', namespace="accounts")),
    url(r'', include(nsurl, namespace="uconnjobsearch")),
]
