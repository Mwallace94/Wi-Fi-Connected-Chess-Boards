from django.shortcuts import render
from django.shortcuts import redirect
from django.template import RequestContext
from django.http import HttpResponse
from django.http import HttpRequest
from django.http import HttpResponseRedirect
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.core.urlresolvers import reverse
from Queries.jobqueries import *
from Queries.populatequeries import *
from Queries.resumequeries import *
from Queries.userqueries import *
from Queries.adminqueries import *
from accounts.auth import isAuthenticated
from accounts.auth import loginUser
from accounts.auth import logoutUser
from accounts.auth import getLoggedUsername
from django.core.servers.basehttp import FileWrapper
import re

#decorator to check if the user is logged in
def login_required(fn):
    def wrapper(*args, **kwargs):
        if not isAuthenticated(args[0]): #request is always the first argument
            return HttpResponseRedirect(reverse('uconnjobsearch:home'))
        else:
            return fn(*args, **kwargs)
    return wrapper

#small helper function
def checkdict(keys, d):
    for k in keys:
        if not d[k]:
            raise KeyError("The key %s had an empty value" % k)

def checkdate(*args):
    regex = '[0-9]{2}/[0-9]{2}/[0-9]{4}'
    for date in args:
        if not re.match(regex,date):
            return False
    return True

def home(request, extras={}):
    if isAuthenticated(request):
        return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        #return HttpResponseRedirect('/ujs/dashboard/')
    else:
        states = getStates()
        context = {'stateList':states}
        context.update(extras)
        return render(request, 'uconnjobsearch/home.html', context)

@login_required
def dashboard(request):
    # if not isAuthenticated(request):
    #     #strerr = "You must be logged in to view this page."
    #     #return render(request, 'uconnjobsearch/permissions.html', {'msg':strerr})
    #     return HttpResponseRedirect(reverse('uconnjobsearch:home'))
    # else:
    userinfo = getUserInfo(getLoggedUsername(request))
    username = userinfo['UName']
    fname = userinfo['UFName']
    lname = userinfo['ULName']
    poster = isPoster(username)
    seeker = isSeeker(username)
    admin = isAdmin(username)
    postedJobs = getPostedJobs(username)
    appliedFor = getJobsAppliedFor(username)
    resumeList = getResumes(username)
    context = RequestContext(request, {
        'isPoster':poster, 'isSeeker':seeker, 'isAdmin':admin, 'username':username, 'fname':fname,
        'postedJobs':postedJobs, 'appliedList':appliedFor, 'resumeList':resumeList, 'lname':lname
    })
    return render(request, 'uconnjobsearch/dashboard.html', context)

@login_required
@sensitive_post_parameters()
@csrf_protect
@never_cache
def edituser(request, extras={}):
    if request.method == 'GET':
        userinfo = getUserInfo(getLoggedUsername(request))
        states = getStates()
        context = {'userInfo':userinfo, 'stateList':states}
        context.update(extras)
        return render(request, 'uconnjobsearch/edituser.html', context)
    elif request.method == 'POST':
        #copied from accounts/views.py register function
        #this could be made cleaner with request.POST.get('name', '') instead of using a try/except
        try:
            reqposts = ['name', 'fname', 'lname', 'street1', 'city', 'state',
                        'zip', 'email', 'phone']
            optposts = ['street2, fax, cell, homepage', 'pass', 'pass2']
            data = request.POST
            checkdict(reqposts, data)
            if data['pass'] != data['pass2']:
                passMatchErr = "The entered passwords did not match."
                #return the filled out form, but now with an error message
                request.method = 'GET'
                return edituser(request, {'editError':passMatchErr})
                #return render(request, 'uconnjobsearch/edituser.html', {'editerror':passMatchErr})
        except KeyError:
            editError = "Please fill out all of the required fields to update your profile."
            request.method = 'GET'
            return edituser(request, {'editError':editError})
            #return render(request, 'uconnjobsearch/edituser.html', {'editError': editError})
        else:
            #i messed up when specifying what the names of the post variables will be and
            #don't want to change the spec after releasing it to the group, so here we go...
            userinfo = {'UName':data['name'], 'UPasswd':data['pass'], 'UFName':data['fname'],
                        'ULName':data['lname'], 'UStreet1':data['street1'], 'UStreet2':data['street2'],
                        'UCity':data['city'], 'StateID':data['state'], 'Zipcode':data['zip'],
                        'UEmail':data['email'], 'UPhone':data['phone'], 'UFax':data['fax'],
                        'UCell':data['cell'], 'UHomePage':data['homepage'], 'UStatusID':""}
            updateUserInfo(userinfo)
            return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))

@login_required
def searchjobs(request):
    user = getLoggedUsername(request)
    if isPoster(user):
        err = "Only job seekers can use this feature."
        return render(request, 'uconnjobsearch/permissions.html', {'msg':err})
    try:
        term = request.GET.get('query','').strip()
        #only run a search if they entered something, otherwise re-display the page
        if term:
            results = getJobs(term)
            return render(request, 'uconnjobsearch/jobsearch.html', {'searchresults':results})
        else:
            return render(request, 'uconnjobsearch/jobsearch.html', {})
    except KeyError:
        #if they did not submit a get parameter
        #will be the case if they visit the page without typing in a search
        return render(request, 'uconnjobsearch/jobsearch.html', {})

@login_required
def viewresume(request, resumeID):
    user = getLoggedUsername(request)
    resume = viewResume(resumeID)
    rdict = resume['resume']
    if not(ownsResume(user, resumeID) or isAdmin(user)):
        msg = "This resume does not belong to you!"
        return render(request, 'uconnjobsearch/permissions.html', {'msg':msg})
    if request.method == 'GET':
        #show the resume if the user owns it
        if not resume:
            #could not find a resume in the db with the matching ID
            strerr = "The requested resume does not exist."
            return render(request, 'uconnjobsearch/viewresume.html', {'error':strerr})
        else:
            return render(request, 'uconnjobsearch/viewresume.html', {'rid':resumeID, 'resume':resume})
    #elif request.method == 'POST'
    cmd = request.POST.get('action', '')
    if cmd == 'getresumefile':
        rfile = getResumeFile(resumeID)
        if rfile:
            #wrapper = FileWrapper(rfile)
            response = HttpResponse(rfile, content_type='application/pdf')
            response['Content-Disposition'] = 'attachment; filename=%s' % rdict['RFilename']
            #response['Content-Length'] = rfile.
            return response
        else:
            err = "The requested resume file does not exist."
            return render(request, 'uconnjobsearch/viewresume.html', {'error':strerr})
    else:
        return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        
@login_required
def viewjob(request, jobID):
    jobInfo = viewJob(jobID)
    if not jobInfo:
        strerr = "Sorry, the requested job does not exist."
        return render(request, 'uconnjobsearch/viewjob.html', {'error':strerr})
    user = getLoggedUsername(request)
    poster = isPoster(user)
    seeker = isSeeker(user)
    resumes = getResumes(user)
    context = RequestContext(request, {
        'jobInfo':jobInfo, 'resumes':resumes, 'isPoster':poster, 'isSeeker':seeker
    })
    return render(request, 'uconnjobsearch/viewjob.html', context)

@login_required
def changejob(request):
    if request.method == 'GET':
        #this url is only for recieving commands to modify a job
        #users should not try to go here...
        return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
    try:
        cmd = request.POST['changetype']
        jobID = request.POST['jid']
        user = getLoggedUsername(request)
        msg = "There was an error performing your action"
        if cmd == 'deleteapp':
            #delete the seekers application to this job
            deleteApp(user, jobID)
            msg = "Your job application was deleted."
        elif cmd == 'jobfillstatus':
            #toggle the job fill status
            if hasPosted(user, jobID):
                changeFilledStatus(jobID)
                msg = "You have changed the fill status of the job."
        elif cmd == 'jobdelete':
            #delete the job if permissions allow
            if hasPosted(user, jobID):
                deleteJob(jobID)
                msg = "You have deleted the job."
        elif cmd == 'applyforjob':
            #the seeker is applying for this job
            if isSeeker(user):
                #returns an error message if something went wrong
                msg = applyForJob(user, jobID, request.POST['arg'])
                if not msg:
                    msg = "You have successfully applied for the job."
        #after doing the command, just go to the homepage
        return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
    except KeyError:
        #we did not recieve something that we expected, not sure where to 
        #put the user if we reach this point
        return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))

@login_required
def postjob(request):
    user = getLoggedUsername(request)
    if not isPoster(user) and not isAdmin(user):
        err = "You must be a job poster to post a job."
        return render(request, 'uconnjobsearch/permissions.html', {'msg':err})
    if request.method == 'GET':
        states = getStates()
        skills = getSkills()
        dareas = getDegreeAreas()
        dtypes = getDegreeTypes()
        context = RequestContext(request, {
            'statelist':states, 'skills':skills, 'degtypes':dtypes, 'degareas':dareas
        })
        return render(request, 'uconnjobsearch/postjob.html', context)
    elif request.method == 'POST':
        try:
            #get all the posts, make sure the posts arent empty
            #assemble the job dictionary
            #call postJob
            reqposts = ['title', 'city', 'state', 'zip', 'duties', 'yrsXp', 'lowsal',
                        'highsal', 'companyName']
            p = request.POST
            checkdict(reqposts, p)

            job = {'JobID':'', 'JListDate':'', 'JobTitle':p['title'], 'JCity':p['city'], 'StateID':p['state'],
                   'Zipcode':p['zip'], 'JDuties':p['duties'], 'JYRSExperience':p['yrsXp'],
                   'JLowRange':p['lowsal'], 'JHighRange':p['highsal'], 'JFillStatus':'No',
                   'CName':p['companyName']}
            areas = p.getlist('degreeareas', '')
            types = p.getlist('degreetypes')
            skills = p.getlist('skills')
            newid = postJob(job, areas, types, skills, user)
            return HttpResponseRedirect(reverse('uconnjobsearch:viewjob', kwargs={'jobID':newid}))
        except KeyError:
            err = "You did not fill out the entire form."
            request.method = 'GET'
            #return render(request, 'uconnjobsearch/postjob.html', {'error':err})
            postjob(request)

@login_required
def editjobattrs(request):
    if request.method == 'GET':
        #this url is only for recieving commands to modify a job
        #users should not try to go here...
        return HttpResponseRedirect(reverse('uconnjobsearch:home'))
    try:
        cmd = request.POST['action']
        arg = request.POST['arg']
        user = getLoggedUsername(request)
        if cmd == 'addskill':
            if isPoster(user):
                addSkill(arg.strip())
    except KeyError:
        pass
    return HttpResponseRedirect(reverse('uconnjobsearch:postjob'))
    
@login_required
def addresume(request):
    user = getLoggedUsername(request)
    if not isSeeker(user):
        msg = "You must have a seeker account to add a resume"
        return render(request, 'uconnjobsearch/permissions.html', {'msg':msg})
    states = getStates()
    skills = getSkills()
    degtypes = getDegreeTypes()
    degareas = getDegreeAreas()
    context = RequestContext(request, {
        'skills':skills, 'degtypes':degtypes, 'degareas':degareas, 'statelist':states
    })
    if request.method == 'GET':
        #reset the info they added
        request.session['addedpjs'] = [] #[{'a':'a'},{'b':'b'},{'c':'c'}]
        request.session['addededus'] = []
        return render(request, 'uconnjobsearch/addresume.html', context)
    #elif request.method == 'POST':
    try:
        cmd = request.POST['action']
        user = getLoggedUsername(request)
        post = request.POST
        if cmd == 'addpriorjob':
            reqposts = ['PJCompanyName', 'PJJobTitle', 'PJDuties', 'PJCity', 'StateID', 'PJStartDate', 'PJEndDate']
            checkdict(reqposts, post)
            if not checkdate(post['PJStartDate'],post['PJEndDate']):
                raise KeyError("Incorrect date format while adding a prior job.")
            pj = post.dict()
            l = request.session['addedpjs']
            l.append(pj)
            request.session['addedpjs'] = l
            context.update({'addedpriorjobs':l, 'addededucations':request.session['addededus']})
            return render(request, 'uconnjobsearch/addresume.html', context)
        elif cmd == 'addeducation':
            reqposts = ['UniversityName', 'EGPA', 'EstartDate', 'EGradDate', 'DegreeTypeID', 'DegreeAreaID']
            checkdict(reqposts, post)
            if not checkdate(post['EstartDate'],post['EGradDate']):
                raise KeyError("Incorrect date format while adding an education.")
            edu = post.dict()
            l = request.session['addededus']
            l.append(edu)
            request.session['addededus'] = l
            context.update({'addededucations':l, 'addedpriorjobs':request.session['addedpjs']})
            return render(request, 'uconnjobsearch/addresume.html', context)
        elif cmd == 'discard':
            del request.session['addededus']
            del request.session['addedpjs']
            return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        elif cmd == 'publishresume':
            #assemble all the post data
            rdict = post.dict()
            rdict.update({'ResumeID':'', 'UName':user})
            priorjobs = request.session['addedpjs']
            educations = request.session['addededus']
            skillset = post.getlist('skills')
            resumefile = request.FILES.get('resumefile', None)
            addResume(rdict, educations, priorjobs, skillset, resumefile)
            return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        else: #got an unknown command
            return render(request, 'uconnjobsearch/addresume.html', {'error':'Invalid post command'})
    except KeyError as e:
        context.update({'error':str(e), 'addededucations':request.session['addededus'],
                        'addedpriorjobs':request.session['addedpjs']})
        return render(request, 'uconnjobsearch/addresume.html', context)

@login_required
def editresume(request, resumeID):
    user = getLoggedUsername(request)
    resume = viewResume(resumeID)
    #shouldn't need to check for existance of the resume with this below function
    if not ownsResume(user, resumeID):
        msg = "This resume does not belong to you!"
        return render(request, 'uconnjobsearch/permissions.html', {'msg':msg})
    states = getStates()
    skills = getSkills()
    degtypes = getDegreeTypes()
    degareas = getDegreeAreas()
    context = {'resume':resume, 'rid':resumeID, 'statelist':states, 'skills':skills, 'degtypes':degtypes,
               'degareas':degareas}
    if request.method == 'GET':
        request.session['addedpjs'] = []
        request.session['addededus'] = []
        return render(request, 'uconnjobsearch/editresume.html',context)
    #elif request.method == 'POST':
    try:
        post = request.POST
        session = request.session
        cmd = post['action']
        if cmd == 'addpriorjob':
            reqposts = ['PJCompanyName', 'PJJobTitle', 'PJDuties', 'PJCity', 'StateID', 'PJStartDate', 'PJEndDate']
            checkdict(reqposts, post)
            if not checkdate(post['PJStartDate'],post['PJEndDate']):
                raise KeyError("Incorrect date format while adding a prior job.")
            pj = post.dict()
            l = session['addedpjs']
            l.append(pj)
            session['addedpjs'] = l
            context.update({'addedpriorjobs':l, 'addededucations':session['addededus']})
            return render(request, 'uconnjobsearch/editresume.html', context)
        elif cmd == 'addeducation':
            reqposts = ['UniversityName', 'EGPA', 'EstartDate', 'EGradDate', 'DegreeTypeID', 'DegreeAreaID']
            checkdict(reqposts, post)
            if not checkdate(post['EstartDate'],post['EGradDate']):
                raise KeyError("Incorrect date format while adding an education.")
            edu = post.dict()
            l = session['addededus']
            l.append(edu)
            session['addededus'] = l
            context.update({'addededucations':l, 'addedpriorjobs':session['addedpjs']})
            return render(request, 'uconnjobsearch/editresume.html', context)
        elif cmd == 'cancel':
            del session['addededus']
            del session['addedpjs']
            return HttpResponseRedirect(reverse('uconnjobsearch:viewresume', kwargs={'resumeID':resumeID}))
        elif cmd == 'delete':
            if not deleteResume(resumeID):
                msg = "You cannot delete a resume that is used in a job application."
                context.update({'error':msg, 'addededucations':session['addededus'],
                                'addedpriorjobs':session['addedpjs']})
                return render(request, 'uconnjobsearch/editresume.html', context)
            del session['addededus']
            del session['addedpjs']
            return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        elif cmd == 'saveresume':
            #assemble all the post data
            resume = {'ResumeID':resumeID, 'RObjective':post['RObjective'], 'RSalaryMin':post['RSalaryMin'], 'RName':post['RName']}
            addedpjs = session['addedpjs']
            addededus = session['addededus']
            deletededus = post.getlist('deletededus')
            deletedpjs = post.getlist('deletedpjs')
            skillset = post.getlist('skills')
            resumefile = request.FILES.get('resumefile', None)
            updateResume(resume, addedpjs, addededus, deletedpjs, deletededus, skillset, resumefile)
            return HttpResponseRedirect(reverse('uconnjobsearch:dashboard'))
        else: #got an unknown command
            return render(request, 'uconnjobsearch/editresume.html', {'error':'Invalid post command'})
    except KeyError as e:
        err = "Please fill out all the required fields"
        context.update({'error':err, 'addededucations':session['addededus'],
                        'addedpriorjobs':session['addedpjs']})
        return render(request, 'uconnjobsearch/editresume.html', context)


# @login_required
# def resumebuilder(request):
#     if request.method == 'GET':
#         return HttpResponseRedirect(reverse('uconnjobsearch:addresume'))
#     try:
#         cmd = request.POST['action']
#         user = getLoggedUsername(request)
#         p = request.POST
#         if cmd == 'addpriorjob':
#             reqposts = ['PJCompanyName', 'PJJobTitle', 'PJDuties', 'PJCity', 'StateID', 'PJStartDate', 'PJEndDate']
#             checkdict(reqposts, p)
#             pj = p.dict()
#             request.session['addedpjs'] = request.session.get('addedpjs', []).append(pj)
#         elif cmd == 'addeducation':
#             reqposts = ['UniversityName', 'EGPA', 'EstartDate', 'EGradDate', 'DegreeTypeID', 'DegreeAreaID']
#             checkdict(reqposts, p)
#             edu = p.dict()
#             request.session['addededus'] = request.session.get('addededus', []).append(edu)
#         elif cmd == 'discard':
#             del request.session['addededus']
#             del request.session['addedpjs']
#         elif cmd == 'publishresume':
#             pass
#         #if the command wasn't found...
#         request.method = 'GET'
#         return addresume(request)
#     except KeyError:
#         pass

@login_required
def adminpanel(request):
    skills = getSkills()
    if request.method == 'GET':
        return render(request, 'uconnjobsearch/admin.html', {'skills':skills})
    
    try:
        reportid = request.POST['reportid']
        arg1 = request.POST['arg1']
        data = None
        message = "You did not select a valid report."
        if reportid == '1':
            data = adminGetSeekers()
            message = "All job seekers alphabetically by state"
        elif reportid == '2':
            data = adminGetJobsAppliedFor(arg1)
            message = "All jobs that the seeker with last name %s has applied for" % arg1
        elif reportid == '3':
            data = adminGetJobsByCompany(arg1)
            message = "All jobs posted by the company %s" % arg1
        elif reportid == '4':
            arg2 = request.POST['arg2']
            #dates are MM/DD/YYYY
            #regex = '[0-9]{2}/[0-9]{2}/[0-9]{4}'
            #if re.match(regex,arg1) and re.match(regex,arg2):
            if checkdate(arg1,arg2):
                data = getJobsByDate(arg1, arg2)
                message = "All jobs posted between %s and %s" % (arg1, arg2)
            else:
                data = ''
                message = "Incorrect date format"
        elif reportid == '5':
            arg2 = request.POST['arg2']
            data = adminGetJobsBySalaryTitle(arg1, arg2)
            message = "All jobs with %s in their salary range, and with a title of %s" % (arg1, arg2)
        elif reportid == '6':
            data = adminSeekersForJob(arg1)
            message = "All the seekers who applied for the job id %s" % arg1
        elif reportid == '7':
            data = getSeekersFromUniversity(arg1)
            message = "All the seekers from the university %s" % arg1
        elif reportid == '8':
            return render(request, 'uconnjobsearch/admin.html', {'message':message, 'skills':skills})
        elif reportid == '9':
            arg1 = request.POST.getlist('arg1')
            data = getJobsWithSkills(arg1)
            message = "All the jobs with skills matching %s" % arg1
        elif reportid == '10':
            arg1 = request.POST.getlist('arg1')
            data = getSeekersWithSkills(arg1)
            message = "All the seekers with skills matching %s" % arg1
        else:
            return render(request, 'uconnjobsearch/admin.html', {'message':message, 'skills':skills})
        
        return render(request, 'uconnjobsearch/admin.html', {'message':message, 'skills':skills, 'data':data})
        
    except KeyError:
        return render(request, 'uconnjobsearch/admin.html', {'message':"Invalid post parameter", 'skills':skills})
