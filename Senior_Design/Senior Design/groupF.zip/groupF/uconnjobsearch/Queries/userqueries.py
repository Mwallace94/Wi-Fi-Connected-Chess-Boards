from __future__ import unicode_literals

from django.db import connection

#creates a dictionary from a set of queries
def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#checks if the given user is an admin - returns true if they are, false if not
def isAdmin(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM administrator WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#checks if the given user is a seeker - returns true if they are, false if not
def isSeeker(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM seeker WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#checks if the given user is a poster - returns true if they are, false if not
def isPoster(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM poster WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#print "dict['Name']: ", dict['Name'];

#testdict = {'UName': 'herbert', 'UPasswd': 'herbert', 'UFName': 'Herbert', 'ULName': 'Smith', 'UStreet1': '', 'UStreet2':'', 'UCity': '', \
#'StateID': '', 'Zipcode': '', 'UEmail':'', 'UPhone':'', 'UFax': '', 'UCell': '', 'UHomepage': ''}

#returns true on successful insertion user
def registerUser(udict):
    cursor = connection.cursor()
    #list of args for the insertion (taken from input dictionary)
    queryargs = [udict['UName'], udict['UPasswd'], udict['UFName'], udict['ULName'], udict['UStreet1'], udict['UStreet2'], \
    udict['UCity'], udict['StateID'], udict['Zipcode'], udict['UEmail'], udict['UPhone'], udict['UFax'], udict['UCell'], udict['UHomePage'], ""]


    checkIntegrity = cursor.execute("SELECT UName FROM user WHERE UName=%s", [udict['UName']])
    #if the username doesnt already exist, add the user
    if not checkIntegrity:
        cursor.execute("INSERT INTO user VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", queryargs)
        cursor.execute("INSERT INTO seeker (UName) VALUES (%s)", [udict['UName']])

        return True
    #return false if we weren't able to insert because primary key wasn't unique
    return False

def getUserInfo(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName, UFName, ULName, UStreet1, UStreet2, UCity, StateID, Zipcode, UEmail, UPhone, UFax, UCell, UHomePage FROM user WHERE UName=%s", [uname])
    userInfo = dictfetchall(cursor)

    return userInfo[0]

def authenticateUser(uname, passwd):
    cursor = connection.cursor()
    #passwd = hash(passwd)
    cursor.execute("SELECT UPasswd FROM user WHERE UName=%s", [uname])
    userpass = cursor.fetchone()
    #if the query returned nothing, the username was not defined
    if not userpass:
        return False
    userpass = userpass[0]
    if userpass == passwd:
        return True
    else:
        return False

#CHANGE TO UPDATES
def updateUserInfo(udict):
    cursor = connection.cursor()
    #if password field was empty, don't update the password
    if not udict['UPasswd']:
        cursor.execute("UPDATE user SET UFName=%s, ULName=%s, UStreet1=%s, UStreet2=%s, UCity=%s, StateID=%s, Zipcode=%s, UEmail=%s, UPhone=%s, UFax=%s, UCell=%s, UHomePage=%s WHERE UName=%s", \
        [udict['UFName'], udict['ULName'], udict['UStreet1'], udict['UStreet2'], udict['UCity'], udict['StateID'], udict['Zipcode'], udict['UEmail'], udict['UPhone'], udict['UFax'], udict['UCell'], udict['UHomePage'], udict['UName']])
    #otherwise, update the password too
    else:
        cursor.execute("UPDATE user SET UPasswd=%s, UFName=%s, ULName=%s, UStreet1=%s, UStreet2=%s, UCity=%s, StateID=%s, Zipcode=%s, UEmail=%s, UPhone=%s, UFax=%s, UCell=%s, UHomePage=%s WHERE UName=%s", \
        [udict['UPasswd'], udict['UFName'], udict['ULName'], udict['UStreet1'], udict['UStreet2'], udict['UCity'], udict['StateID'], udict['Zipcode'], udict['UEmail'], udict['UPhone'], udict['UFax'], udict['UCell'], udict['UHomePage'], udict['UName']])
        #cursor.execute("INSERT INTO user (UPasswd, UFName, ULName, UStreet1, UStreet2, UCity, StateID, Zipcode, UEmail, UPhone, UFax, UCell, UHomePage) VALUES WHERE UName=%s \
        #(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", [udict['UName'], udict['UPasswd'], udict['UFName'], udict['ULname'], udict['UStreet1'], udict['UStreet2'], udict['UCity'], udict['StateID'], udict['Zipdoce'], udict['UEmail'], udict['UPhone'], udict['UFax'], udict['UCell'], udict['UHomePage']])

#def getTestDict(ucity):
#    cursor = connection.cursor()
#    cursor.execute("SELECT * FROM user WHERE UCity=%s", [ucity])
#    rv = dictfetchall(cursor)
#
#    return rv
