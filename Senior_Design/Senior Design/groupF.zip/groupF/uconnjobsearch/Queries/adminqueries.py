from __future__ import unicode_literals

from django.db import connection

#creates a dictionary from a set of queries
def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#returns dicts with requested details for all job seekers ordered by state and last name alphabetically
#admin query #1
def adminGetSeekers():
    cursor = connection.cursor()
    cursor.execute("SELECT UFName, ULName, UStreet1, UStreet2, UCity, Abbr, Zipcode, UEmail FROM user, state WHERE user.stateID=state.stateID AND UName IN (SELECT UName FROM seeker) ORDER BY Abbr, ULName")

    seekers = dictfetchall(cursor)

    return seekers;

#returns dicts with requested details for all job seekers when searched for by last name
#admin query #2
def adminGetJobsAppliedFor(lname):
    cursor = connection.cursor()
    cursor.execute("SELECT ULName, UFName, CName, JobID, JListDate, JobTitle FROM user,job WHERE user.ULName=%s AND job.JobID IN (SELECT JobID FROM applies WHERE user.UName=applies.UName)", [lname])

    jobs = dictfetchall(cursor)

    return jobs;

#returns dicts with requested details for the given company name
#admin query #3
def adminGetJobsByCompany(cname):
    cursor = connection.cursor()
    cursor.execute("SELECT JobID, JListDate, JobTitle, JFillStatus FROM job WHERE CName='A&T Systems, Inc.' ORDER BY JobTitle")

    jobs = dictfetchall(cursor)

    return jobs;

#returns dicts with the requested infor for jobs between two given dates
#STR_TO_DATE((SELECT JListDate FROM job WHERE JobID=1),'%m/%d/%Y')
def getJobsByDate(startDate, endDate):
    cursor = connection.cursor()
    #converts string formats stored in DB to dates for comparisons
    cursor.execute("SELECT CName, JobID, JListDate, JobTitle FROM job WHERE (STR_TO_DATE(JListDate,'%%m/%%d/%%Y') >= STR_TO_DATE(%s,'%%m/%%d/%%Y')) AND (STR_TO_DATE(JListDate,'%%m/%%d/%%Y') <= STR_TO_DATE(%s,'%%m/%%d/%%Y'))", [startDate, endDate])
    #("SELECT CName, JobID, JListDate, JobTitle FROM job WHERE (STR_TO_DATE(JListDate,'%m/%d/%Y') >= STR_TO_DATE(%s,'%m/%d/%Y')) AND (STR_TO_DATE(JListDate,'%m/%d/%Y') <= STR_TO_DATE(%s,'%m/%d/%Y'))", [startDate, endDate])
    jobs = dictfetchall(cursor)

    return jobs

#returns dicts with requested details for the given salary and job title
#admin query #5
def adminGetJobsBySalaryTitle(salary, title):
    cursor = connection.cursor()
    cursor.execute("SELECT CName, JobID, JListDate, JLowRange, JHighRange FROM job WHERE %s BETWEEN JLowRange AND JHighRange AND JobTitle=%s", [salary, title])

    jobs = dictfetchall(cursor)

    return jobs;

#returns dicts with requested details for the seekers for the given job id
#admin query #6
def adminSeekersForJob(jobid):
    cursor = connection.cursor()
    cursor.execute("SELECT UFName, ULName, UStreet1, UStreet2, UCity, Abbr, Zipcode, UEmail FROM user, state WHERE user.stateID=state.stateID AND UName in (SELECT UName FROM applies WHERE JobID=%s)", [jobid])

    seekers = dictfetchall(cursor)

    return seekers

#returns dicts with requested details for the seekers that graduated from the given university with a bachelors degree
#admin query #7
def getSeekersFromUniversity(universityname):
    cursor = connection.cursor()
    #                ------------------------------------Gets info --------------------------------------------------------------------------              gets usernames for resumes that meet conditions       gets resumeIDs that meet education requirements -----------------------------------------------------------education requirements--------------------------------------------------------------------------                                                                                                                                
    cursor.execute("SELECT UFName, ULName, UStreet1, UStreet2, UCity, Abbr, Zipcode, UEmail FROM user, state WHERE user.stateID=state.stateID AND UName IN (SELECT DISTINCT UName FROM resume WHERE ResumeID IN (SELECT ResumeID FROM education WHERE EUniversityID=(SELECT universityID FROM university WHERE UniversityName=%s) AND DegreeTypeID=(SELECT DegreeTypeID FROM degreetype WHERE DegreeType='Bachelors Degree')))", [universityname])
    #("SELECT UFName, ULName, UStreet1, UStreet2, UCity, Abbr, Zipcode, UEmail FROM user, state WHERE user.stateID=state.stateID AND UName IN (SELECT DISTINCT UName FROM resume WHERE ResumeID IN (SELECT ResumeID FROM education WHERE UniversityID=(SELECT UniversityID FROM university WHERE UniversityName=%s) AND DegreeTypeID=(SELECT DegreeTypeID FROM degreetype WHERE DegreeType='Bachelor's Degree)))", [universityname])

    seekers = dictfetchall(cursor)

    return seekers;

#returns dicts requested with details for payments made between 2 dates
#admin query #8
def adminGetPaymentReport(startDate, endDate):
    cursor = connection.cursor()
    #cursor.execute("SELECT PaymentID, PAmount, Name, PDate FROM payment, pstatus WHERE pstatus.pstatusID=payment.PStatusID AND (STR_TO_DATE(PDate,'%%m/%d/%Y') >= STR_TO_DATE(%s,'%%m/%%d/%%Y')) AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') <= STR_TO_DATE(%s,'%%m/%%d/%%Y')))", [startDate,endDate])

    #gets payments without type
    #payments = dictfetchall(cursor)

    #checks payment type and adds to dictionary (PType is the key)
    #for p in payments:
    #gets all credit card payments
    cursor.execute("SELECT payment.PaymentID, PAmount, Name, PDate FROM payment, pstatus, creditcard WHERE creditcard.PaymentID = payment.PaymentID AND pstatus.pstatusID=payment.PStatusID AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') >= STR_TO_DATE(%s,'%%m/%%d/%%Y')) AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') <= STR_TO_DATE(%s,'%%m/%%d/%%Y'))", [startDate,endDate])
    ccpayments = dictfetchall(cursor)
    #add the type to the dict
    for p in ccpayments:
        p.update({'PType': 'Credit Card'})

    #gets all bank payments
    cursor.execute("SELECT payment.PaymentID, PAmount, Name, PDate FROM payment, pstatus, bankpayment WHERE bankpayment.PaymentID = payment.PaymentID AND pstatus.pstatusID=payment.PStatusID AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') >= STR_TO_DATE(%s,'%%m/%%d/%%Y')) AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') <= STR_TO_DATE(%s,'%%m/%%d/%%Y'))", [startDate,endDate])
    bankpayments = dictfetchall(cursor)
    #adds type to dict
    for p in bankpayments:
        p.update({'PType': 'Bank Payment'})

    #gets all online service payments
    cursor.execute("SELECT payment.PaymentID, PAmount, Name, PDate FROM payment, pstatus, onlineservice WHERE onlineservice.PaymentID = payment.PaymentID AND pstatus.pstatusID=payment.PStatusID AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') >= STR_TO_DATE(%s,'%%m/%%d/%%Y')) AND (STR_TO_DATE(PDate,'%%m/%%d/%%Y') <= STR_TO_DATE(%s,'%%m/%%d/%%Y'))", [startDate,endDate])
    onlinepayments = dictfetchall(cursor)
    #adds type to dict
    for p in onlinepayments:
        p.update({'PType': 'Online Service'})

    payments = ccpayments + bankpayments + onlinepayments

    return payments

#returns dicts with requested details for jobs that have one or more of the skills in the skills list
#admin query #9
def getJobsWithSkills(skills):
    cursor = connection.cursor()
    cursor.execute("SELECT JobID, JListDate, JobTitle FROM job WHERE JobID IN (SELECT JobID FROM job_skills WHERE SSkillID IN %s)", [skills])

    jobs = dictfetchall(cursor)

    return jobs

#returns dicts with requested details for seekers that have all of the skills in the skills list
#admin query #10
def getSeekersWithSkills(skills):
    seekers = []
    skillsets = []
    cursor = connection.cursor()

    #gets all resumeIDs that have skills on them
    cursor.execute("SELECT DISTINCT ResumeID FROM skillset")
    resumeIDs = cursor.fetchall()
    #for each resumeID, get the lsit of skills and see if it matches the list of skills given
    for rid in resumeIDs:
        #gets the list of skills for the given resumeID
        cursor.execute("SELECT SSkillID FROM skillset WHERE ResumeID=%s", [rid[0]])
        skillset = cursor.fetchall()
        #converts list of skills for a given resume ID to a list we can use
        skillsets.append((rid, convertToList(skillset)))

    #checks if the skillset in the db for the given resumeID matches the skillset given as an argument
    for s in skillsets:
        if set(skills).issubset(set(s[1])):
            cursor.execute("SELECT UFName, ULName, UStreet1, UStreet2, UCity, Abbr, Zipcode, UEmail FROM user, state WHERE user.stateID=state.stateID AND UName=(SELECT UName FROM resume WHERE ResumeID=%s)", [s[0]])
            #adds dict to list if the skillset matches the entered skills
            seekers = seekers + dictfetchall(cursor)
        
    return seekers

#converts a list of single elements from a fetchall() call into a list (formatting is weird for single elements)
def convertToList(cursorResult):
    l = []
    for x in cursorResult:
        l.append(str(x[0]))

    return l


