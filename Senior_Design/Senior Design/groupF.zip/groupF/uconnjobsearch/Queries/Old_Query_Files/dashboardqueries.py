#Dashboard functions
from __future__ import unicode_literals

from django.db import connection

def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#gets job title, resumeid, company name, and job id for all jobs that a user has applied for
def getJobsAppliedFor(uname):
    cursor = connection.cursor()
    #gets job title, company name, and job id for jobs applied for
    cursor.execute("SELECT JobTitle, CName, JobID FROM job WHERE job.JobID IN (SELECT JobID FROM applies WHERE UName=%s)", [uname]);
    jobs = dictfetchall(cursor)

    for job in jobs:
        #gets resumeID for this job and adds it to the dict
        rid = cursor.execute("SELECT ResumeID FROM applies WHERE UName=%s AND JobID=%s", [uname, job['JobID']])
        job.update(ResumeID = rid)

    return jobs

#gets all of a user's posted jobs (database assumes each user can only post for one company, but not necessarily vice versa)
def getPostedJobs(uname):
    cursor = connection.cursor()
    #gets job title and id for a poster
    cursor.execute("SELECT JobID, JobTitle FROM job WHERE job.CName=(SELECT CName FROM poster WHERE UName=%s)", [uname])
    jobs = dictfetchall(cursor)

    return jobs

    #query for addition of posts table
    #SELECT JobID, JobTitle FROM job WHERE job.JobID IN (SELECT JobID from posts WHERE UName=uname)

     #returns details about a job for a given job id (meant to be used by poster and by job search function on apply page)

#all info used in details for poster, shared function with job application details, but no fill status
#NEEDS TESTING AS A WHOLE
def viewJob(jid):
    cursor = connection.cursor()

    #gets basic job info from job table
    cursor.execute("SELECT JListDate,JobTitle,JCity,Abbr,Zipcode,JDuties,JYRSExperience,JLowRange,JHighRange,JFillStatus,CName \
    FROM job,state WHERE state.stateID=job.StateID AND JobID=%s", [jid])
    details = dictfetchall(cursor)

    #gets list of degree areas for this job (list of strings)
    cursor.execute("SELECT DegreeArea from degreearea WHERE DegreeAreaID IN (SELECT DegreeAreaID FROM job_degreearea WHERE JobID=%s)", [jid])
    degreeAreas = cursor.fetchall()

    #gets list of degree types for this job
    cursor.execute("SELECT DegreeType from degreeType WHERE DegreeTypeID IN (SELECT DegreeTypeID FROM job_degreetype WHERE JobID=%s)", [jid])
    degreeTypes = cursor.fetchall()

    #gets a list of skills for a job (names only)
    cursor.execute("SELECT SSkillName FROM skill WHERE skill.SSkillID IN (SELECT SSkillID FROM job_skills WHERE JobID=%s);", [rid])
    skillList = cursor.fetchall()

    details.update(job_degreearea = degreeAreas, job_degreetype = degreeTypes, job_skills = skillList)

    return details
    

#---RESUME FUNCTIONS---

#returns a list of dicts with resume names and IDs for the given username
def getResumes(uname):
    cursor = connection.cursor()

    cursor.execute("SELECT RName, ResumeID FROM resume WHERE UName=%s", [uname])
    resumes = dictfetchall(cursor)

    return resumes

#note that in the resume dict, the list of prior jobs is called priorjobs, the list of skills is called skillset, and the list of education is called education
#NEEDS TESTING AS A WHOLE
def viewResume(rid):
    cursor = connection.cursor()

    #resume details, including file for future use, but not used now
    cursor.execute("SELECT RObjective, RSalaryMin, RFile, RName FROM resume WHERE ResumeID=%s", [rid])
    resumeDict = dictfetchall(cursor)

    #gets prior job details as a list of dicts
    cursor.execute("SELECT PJCompanyName,PJJobTitle,PJDuties,PJCity,Abbr,PJStartDate,PJEndDate FROM state,priorjobs WHERE state.StateID=priorjobs.StateID AND ResumeID=%s", [rid])
    priorJobs = dictfetchall(cursor)

    #gets list of skills by name (list of skill names and IDs - ID info to be used for update resume)
    cursor.execute("SELECT SSkillName,SSkillID FROM skill WHERE skill.SSkillID IN (SELECT SSkillID FROM skillset WHERE ResumeID=%s);", [rid])
    skillList = cursor.fetchall()

    cursor.execute("SELECT UniversityName, EGPA, EstartDate, EGradDate, DegreeType, DegreeArea FROM university,education,degreearea,degreetype \
    WHERE ResumeID=%s AND education.DegreeTypeID=degreetype.DegreeTypeID AND education.DegreeAreaID=degreearea.DegreeAreaID AND EUniversityID=UniversityID;", [rid])
    educationList = dictfetchall(cursor)

    resumeDict.update(priorjobs = priorJobs, skillset = skillList, education = educationList)

    return resumeDict

   