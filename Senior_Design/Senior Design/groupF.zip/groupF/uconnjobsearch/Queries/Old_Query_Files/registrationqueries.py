from __future__ import unicode_literals

from django.db import connection

#creates a dictionary from a set of queries
def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#checks if the given user is an admin - returns true if they are, false if not
def isAdmin(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM administrator WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#checks if the given user is a seeker - returns true if they are, false if not
def isSeeker(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM seeker WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#checks if the given user is a poster - returns true if they are, false if not
def isPoster(uname):
    cursor = connection.cursor()
    cursor.execute("SELECT UName FROM poster WHERE UName=%s;", [uname])
    res = cursor.fetchone()

#   #if the username query came back as existing (non-empty string), return true
    if res:
        return True

#   #otherwise, return false
    return False

#print "dict['Name']: ", dict['Name'];

#testdict = {'UName': 'herbert', 'UPasswd': 'herbert', 'UFName': 'Herbert', 'ULName': 'Smith', 'UStreet1': '', 'UStreet2':'', 'UCity': '', \
#'StateID': '', 'Zipcode': '', 'UEmail':'', 'UPhone':'', 'UFax': '', 'UCell': '', 'UHomepage': ''}

#returns true on successful insertion user
def registerUser(udict):
    cursor = connection.cursor()
    #list of args for the insertion (taken from input dictionary)
    queryargs = [udict['UName'], udict['UPasswd'], udict['UFName'], udict['ULName'], udict['UStreet1'], udict['UStreet2'], \
    udict['UCity'], udict['StateID'], udict['Zipcode'], udict['UEmail'], udict['UPhone'], udict['UFax'], udict['UCell'], udict['UHomepage'], ""]


    checkIntegrity = cursor.execute("SELECT UName FROM user WHERE UName=%s", [udict['UName']])
    #if the username doesnt already exist, add the user
    if not checkIntegrity:
        cursor.execute("INSERT INTO user VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", queryargs)

        return True
    #return false if we weren't able to insert because primary key wasn't unique
    return False

#def getTestDict(ucity):
#    cursor = connection.cursor()
#    cursor.execute("SELECT * FROM user WHERE UCity=%s", [ucity])
#    rv = dictfetchall(cursor)
#
#    return rv