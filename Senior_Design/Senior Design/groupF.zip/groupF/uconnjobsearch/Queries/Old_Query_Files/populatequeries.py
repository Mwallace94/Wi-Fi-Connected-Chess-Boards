#gets lists (skill/ID, degreetype/ID degreearea/ID, state/ID)
from __future__ import unicode_literals

from django.db import connection

#creates a dictionary from a set of queries
def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#returns a list of state dicts (name/ID)
def getStates():
    cursor = connection.cursor

    cursor.execute("SELECT * FROM state")
    states = dictfetchall(cursor)

    return states

#returns a list of skill dicts (name/ID)
def getSkills():
    cursor = connection.cursor

    cursor.execute("SELECT * FROM skill")
    skills = dictfetchall(cursor)

    return skills

#returns a list of degree area dicts (name/ID)
def getDegreeAreas():
    cursor = connection.cursor

    cursor.execute("SELECT * FROM degreearea")
    degreeAreas = dictfetchall(cursor)

    return degreeAreas

#returns a list of degree type dicts (name/ID)
def getDegreeTypes():
    cursor = connection.cursor

    cursor.execute("SELECT * FROM degreetype")
    degreeTypes = dictfetchall(cursor)

    return degreeTypes