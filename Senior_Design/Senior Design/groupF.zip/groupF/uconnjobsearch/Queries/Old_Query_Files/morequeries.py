#Dashboard functions
from __future__ import unicode_literals

from django.db import connection
import time

def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#user applies for a job with a specific resume
def applyForJob(uname, jobid, resumeid):
    #current time as a string in mm/dd/yyyy format
    curdate = time.strftime("%m/%d/%Y")

    cursor = connection.cursor()
    cursor.execute("INSERT INTO applies (JobID, UName, DateApplied, ResumeID) VALUES (%s, %s, %s, %s)", [jobid, uname, curdate, resumeid])

#for job search; just use details from poster's details for job details
#jobID, company name, job title, salary min/max, list date for jobs searched by title that are not already filled
def getJobs(title):
    cursor = connection.cursor()
    #gets all unfilled jobs with a title that contains the string searched for
    cursor.execute("SELECT JobID, CName, JobTitle, JLowRange, JHighRange, JListDate, JFillStatus FROM job WHERE JobTitle LIKE %s AND JFillStatus='No'", ["%" + title + "%"])

    jobs = dictfetchall(cursor)

    return jobs

#expects job dict, degree area id, degree type id (use dropdown menus for these options), list of skill IDs
#may not be up to spec, need to check
#job contains title, city, state id, zip, duties, years exp, low, high, company name
#list of numbers for degree area, degree type, skills
#FINISH THIS
def postJob(job, degreearea, degreetype, skills, uname):
    #current time as a string in mm/dd/yyyy format
    curdate = time.strftime("%m/%d/%Y")

    cursor = connection.cursor()
    #generates a unique job id
    cursor.execute("SELECT MAX(JobID) FROM job")
    jid = cursor.fetchone()[0] + 1

    cursor.execute("INSERT INTO job (JobID, JListDate, JobTitle, JCity, StateID, Zipcode, JDuties, JYRSExperience, JLowRange, JHighRange, JFillStatus, CName) VALUES \
    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, curdate, job['JobTitle'], job['StateID'], job['Zipcode'], job['JDuties'], job['JYRSExperience'], job['JLowRange', job['JHighRange'], "No", job['CName']])

#    for skill in skills:
#       cursor.execute("")

    cursor.execute("INSERT INTO posts (JobID, UName) VALUES (%s, %s)", [jid, uname])

#for update resume:
#1.  resume dict(everything)
#2.  add education
#3.  add prior jobs
# Make getEducationDetails(rid) and getPriorJobDetails(rid)
#4.  list all education (and details)
#5. List all prior jobs and details
# update will get a list of pjids and eduids for what should be related to the resume (rid)

#getUserInfo(uname)
#updateUserInfo(userdict)
    #will give back password

def getUserInfo(uname):
    

#assumes that the dict has three things: resume info, education dict list, skill dict list, priorJobs
def addResume(resumedict, education, priorjobs, skillset):
    cursor = connection.cursor()
    cursor.execute("SELECT MAX(ResumeID) FROM resume")
    #gets a unique resume ID
    rid = cursor.fetchone()
    rid = rid[0] + 1

    #adds resume info in resume table
    cursor.execute("INSERT INTO resume (ResumeID, ROBjective, RSalaryMin, UName, RName) VALUES \
    (%s, %s, %s, %s, %s)", [rid, resumedict['RObjective'], resumedict['RSalaryMin'], resumedict['UName'], resumedict['RName']])

    #adds skills for resume
    for skill in skills:
        cursor.execute("INSERT INTO skillset (SSkillID, ResumeID) VALUES (%s, %s)", [rid, skill])

    #adds education for resume
    for edu in education:
        #gets ID of university from given name
        cursor.execute("SELECT UniversityID FROM university WHERE UniversityName=%s", [edu['UniversityName']])
        uid = cursor.fetchone()
        #if the university doesn't already exist, enter it
        if not uid:
            cursor.execute("SELECT MAX(UniversityID) FROM university")
            uid = cursor.fetchone()[0] + 1

            cursor.execute("INSERT INTO university (UniversityID, UniverstyName) VALUES (%s, %s)", [uid, edu['UniversityName']])
        else:
            uid = uid[0]

        #makes a unique educationID
        cursor.execute("SELECT MAX(EducationID) FROM education")
        eid = cursor.fetchone()[0] + 1
        #enters education info
        cursor.execute("INSERT INTO education (EducationID, EUniversityID, EGPA, EstartDate, EGradDate, DegreeTypeID, DegreeAreaID, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s)", [eid, uid, edu['EGPA'], edu['EstartDate'], edu['EGradDate'], edu['DegreeTypeID'], edu['DegreeAreaID'], rid])

    #adds prior jobs for resume
    for job in priorjobs:
        #makes a unique priorJobID
        cursor.execute("SELECT MAX(PjobID) FROM priorjobs")
        jid = cursor.fetchone()[0] + 1
        #enters job info
        cursor.execute("INSERT INTO priorjobs (PjobID, PJCompanyName, PJJobTitle, PJDuties, PJCity, PJStateID, PJStartDate, PJEndDate, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, job['PJCompanyName'], job['PJJobTitle'], job['PJDuties'], job['PJCity'], job['PJStateID'], job['PJStartDate'], job['PJEndDate'], rid])