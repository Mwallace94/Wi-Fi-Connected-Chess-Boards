#query to view resume
from __future__ import unicode_literals

from django.db import connection

def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#note that in the resume dict, the list of prior jobs is called priorjobs, the list of skills is called skillset, and the list of education is called education
#NEEDS TESTING AS A WHOLE
def viewResume(rid):
    cursor = connection.cursor()

    #resume details, including file for future use, but not used now
    cursor.execute("SELECT RObjective, RSalaryMin, RFile, RName FROM resume WHERE ResumeID=%s", [rid])
    resumeDict = dictfetchall(cursor)

    #gets prior job details as a list of dicts
    cursor.execute("SELECT PJCompanyName,PJJobTitle,PJDuties,PJCity,Abbr,PJStartDate,PJEndDate FROM state,priorjobs WHERE state.StateID=priorjobs.StateID AND ResumeID=%s", [rid])
    priorJobs = dictfetchall(cursor)

    #gets list of skills by name (list of skill names and IDs - ID info to be used for update resume)
    cursor.execute("SELECT SSkillName,SSkillID FROM skill WHERE skill.SSkillID IN (SELECT SSkillID FROM skillset WHERE ResumeID=%s);", [rid])
    skillList = cursor.fetchall()

    cursor.execute("SELECT UniversityName, EGPA, EstartDate, EGradDate, DegreeType, DegreeArea FROM university,education,degreearea,degreetype \
    WHERE ResumeID=%s AND education.DegreeTypeID=degreetype.DegreeTypeID AND education.DegreeAreaID=degreearea.DegreeAreaID AND EUniversityID=UniversityID;", [rid])
    educationList = dictfetchall(cursor)

    resumeDict.update(priorjobs = priorJobs, skillset = skillList, education = educationList)

    return resumeDict