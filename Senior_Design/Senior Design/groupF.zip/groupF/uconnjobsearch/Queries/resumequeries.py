#query to view resume info
from __future__ import unicode_literals

from django.db import connection

def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#returns True if the user owns the resume and false otherwise
def ownsResume(uname, rid):
    cursor = connection.cursor()
    cursor.execute("SELECT ResumeID, UName FROM resume WHERE ResumeID=%s AND UName=%s", [rid, uname])
    rv = cursor.fetchone()

    if rv:
        return True
    else:
        return False

#takes resumeID and deletes the resume and all details associated with it
#returns true if the resume is not associated with any applications, and false otherwise
def deleteResume(resumeid):
    #list(set(l1) - set(l2))
    cursor = connection.cursor()

    #checks if we can delete the resume (not used on any applications)
    rv = cursor.execute("SELECT ResumeID FROM applies WHERE ResumeID=%s", [resumeid])

    #if there were results (resume used on an app)
    if not rv:
        #deletes skillset for resume
        cursor.execute("DELETE FROM skillset WHERE ResumeID=%s", [resumeid])
        #deletes education for resume
        cursor.execute("DELETE FROM education WHERE ResumeID=%s", [resumeid])
        #deletes prior jobs for resume
        cursor.execute("DELETE FROM priorjobs WHERE ResumeID=%s", [resumeid])
        #deletes resume entry
        cursor.execute("DELETE FROM resume WHERE ResumeID=%s", [resumeid])

        return True
    else:
        return False


#returns a list of dicts with resume names and IDs for the given username
def getResumes(uname):
    cursor = connection.cursor()

    cursor.execute("SELECT RName, ResumeID FROM resume WHERE UName=%s", [uname])
    resumes = dictfetchall(cursor)

    return resumes

#byte array of file
def getResumeFile(resumeid):
    cursor = connection.cursor()

    cursor.execute("SELECT RFile FROM resume WHERE ResumeID=%s", [resumeid])
    filebytes = cursor.fetchone()[0]

    return filebytes

#------VIEW RESUME--------
#note that in the dict,the resume dict is called resume, the list of prior jobs is called priorjobs, the list of skills is called skillset, and the list of education is called education
#NEEDS TESTING AS A WHOLE
def viewResume(rid):
    cursor = connection.cursor()

    #resume details, file ignored for now
    cursor.execute("SELECT RObjective, RSalaryMin, RName, RFilename FROM resume WHERE ResumeID=%s", [rid])
    resumeDict = dictfetchall(cursor)[0]

    #gets prior job details as a list of dicts (includes ID for update purposes)
    cursor.execute("SELECT PjobID,PJCompanyName,PJJobTitle,PJDuties,PJCity,Abbr,PJStartDate,PJEndDate FROM state,priorjobs WHERE state.StateID=priorjobs.StateID AND ResumeID=%s", [rid])
    priorJobs = dictfetchall(cursor)

    #gets list of skills by name (list of skill names and IDs - ID info to be used for update resume, perhaps)
    cursor.execute("SELECT SSkillName,SSkillID FROM skill WHERE skill.SSkillID IN (SELECT SSkillID FROM skillset WHERE ResumeID=%s);", [rid])
    skillList = dictfetchall(cursor)

    #gets list of education details as a lst of dicts (includes ID for update purposes)
    cursor.execute("SELECT EducationID, UniversityName, EGPA, EstartDate, EGradDate, DegreeType, DegreeArea FROM university,education,degreearea,degreetype \
    WHERE ResumeID=%s AND education.DegreeTypeID=degreetype.DegreeTypeID AND education.DegreeAreaID=degreearea.DegreeAreaID AND EUniversityID=UniversityID;", [rid])
    educationList = dictfetchall(cursor)

    #resumeDict.update(priorjobs = priorJobs, skillset = skillList, education = educationList)
    rv = { 'resume': resumeDict, 'priorjobs': priorJobs, 'skillset': skillList, 'education': educationList }

    return rv

def updateResume(resume, newpjs, newedus, delpjs, deledus, skills, resumefile):
    cursor = connection.cursor()
    cursor.execute("UPDATE resume SET RObjective=%s, RSalaryMin=%s, RName=%s WHERE ResumeID=%s", [resume['RObjective'], resume['RSalaryMin'], resume['RName'], resume['ResumeID']])
    if resumefile:
        #gets file as bytes and filename
        f = resumefile.read()
        fname = resumefile.name

        cursor.execute("UPDATE resume SET RFilename=%s, RFile=%s", [fname, f])

    #clean the priorjobs table
    for pj in delpjs:
        cursor.execute("DELETE FROM priorjobs WHERE PjobID=%s",[pj])
    
    #clean the deleted educations
    for edu in deledus:
        #cursor.execute("DELETE FROM university WHERE UniversityID IN (SELECT EUniversityID FROM education WHERE EducationID=%s)", [edu])
        cursor.execute("DELETE FROM education WHERE EducationID=%s",[edu])


    #insert newly added educations
    for edu in newedus:
        #gets ID of university from given name
        cursor.execute("SELECT UniversityID FROM university WHERE UniversityName=%s", [edu['UniversityName']])
        uid = cursor.fetchone()
        #if the university doesn't already exist, enter it
        if not uid:
            cursor.execute("SELECT MAX(UniversityID) FROM university")
            uid = cursor.fetchone()[0] + 1

            cursor.execute("INSERT INTO university (UniversityID, UniversityName) VALUES (%s, %s)", [uid, edu['UniversityName']])
        else:
            uid = uid[0]

        #makes a unique educationID
        cursor.execute("SELECT MAX(EducationID) FROM education")
        eid = cursor.fetchone()[0] + 1
        #enters education info
        cursor.execute("INSERT INTO education (EducationID, EUniversityID, EGPA, EstartDate, EGradDate, DegreeTypeID, DegreeAreaID, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s)", [eid, uid, edu['EGPA'], edu['EstartDate'], edu['EGradDate'], edu['DegreeTypeID'], edu['DegreeAreaID'], resume['ResumeID']])

    #insert newly added prior jobs
    for job in newpjs:
        #makes a unique priorJobID
        cursor.execute("SELECT MAX(PjobID) FROM priorjobs")
        jid = cursor.fetchone()[0] + 1
        #enters job info
        cursor.execute("INSERT INTO priorjobs (PjobID, PJCompanyName, PJJobTitle, PJDuties, PJCity, StateID, PJStartDate, PJEndDate, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, job['PJCompanyName'], job['PJJobTitle'], job['PJDuties'], job['PJCity'], job['StateID'], job['PJStartDate'], job['PJEndDate'], resume['ResumeID']])


    #------SKILL UPDATE-----
    #gets a list of skill IDs that currently belong to this resume in the DB
    cursor.execute("SELECT SSkillID FROM skillset WHERE ResumeID=%s", [resume['ResumeID']])
    rv = cursor.fetchall()
    #formatting because return list is formatted like this: ((1,), (2,), ...)
    curSkills = []
    for x in rv:
        curSkills.append(x[0])

    skills = list(map(int,skills))

    #calculates updated lists of IDs for insertion and deletion
    deletedSkills = set(curSkills) - set(skills)
    addedSkills = set(skills) - set(curSkills)

    #updates skills
    for s in deletedSkills:
        cursor.execute("DELETE FROM skillset WHERE SSkillID=%s AND ResumeID=%s", [s, resume['ResumeID']])

    for s in addedSkills:
        cursor.execute("INSERT INTO skillset (SSkillID, ResumeID) VALUES (%s, %s)", [s, resume['ResumeID']])

#-----UPDATE RESUME-----
#still need to add update for resume line itself
#education and priorjobs are dicts
#def updateResume(resume, education, priorjobs, skills):
#    #list(set(l1) - set(l2))
#    cursor = connection.cursor()
#    #resume table details update (objective, salarymin, rname )
#    cursor.execute("UPDATE resume SET RObjective=%s, RSalaryMin=%s, RName=%s WHERE ResumeID=%s", [resume['RObjective'], resume['RSalaryMin'], resume['RName'], resume['ResumeID']])
#
 #   #------SKILL UPDATE-----
#    #gets a list of skill IDs that currently belong to this resume in the DB
#    cursor.execute("SELECT SSkillID FROM skillset WHERE ResumeID=%s", resume['ResumeID'])
#    rv = cursor.fetchall()
#    #formatting because return list is formatted like this: ((1,), (2,), ...)
#    for x in rv:
#        curSkills.append(x[0])
#
 #   #calculates updated lists of IDs for insertion and deletion
#    deletedSkills = set(curSkills) - set(skills)
#    addedSkills = set(skills) - set(curSkils)
#
 #   #updates skills
#    for skill in skills:
#        #deletes the skill from the resume
#        if skill in deletedSkills:
#            cursor.execute("DELETE FROM skillset WHERE SSkillID=%s AND ResumeID=%s", [skill, resume['ResumeID']])
#        if skill in addedSkills:
#            cursor.execute("INSERT INTO skillset (SSkillID, ResumeID) VALUES (%s, %s)", [skill, resume['ResumeID']])
#
 #   #-----PRIOR JOB UPDATE------
#    #gets a list of prior job IDs that should belong to this resume
#    #for pjob in priorjobs:
#    #    pjobList.append(edu['PjobID'])
#
 #   #gets a list of prior job IDs that currently belong to this resume in the DB
#    cursor.execute("SELECT PjobID FROM priorjobs WHERE ResumeID=%s", [resume['ResumeID']])
#    rv = cursor.fetchall()
#    #formatting because return list is formatted like this: ((1,), (2,), ...)
#    for x in rv:
#        curPjobs.append(x[0])
#
 #   pjids = []
#    #list of existing jobs to keep associated with the resume
#    for x in priorjobs:
#        if x['PjobID'] is not "":
#            pjids = pjids + x['PjobID']
#
 #   #calculates updated lists for insertion and deletion
#    deletedPjobs = set(curPjobs) - set(pjids)
#    #addedPjobs = set(priorjobs) - set(curPjobs)
#
 #   #updates prior jobs
#    for job in priorjobs:
#        #if the ID for this dict is in the list to delete, delete the row
#        if job['PjobID'] in deletedPjobs:
#            cursor.execute("DELETE FROM priorjobs WHERE PjobID=%s", [job['PjobID']])
#            #if the ID for this dict is in the list to add, add the row
#        #if this doesn;t exist yet, add it
#        elif job['PjobID'] == '':
#            #makes a unique priorJobID
#            cursor.execute("SELECT MAX(PjobID) FROM priorjobs")
#            jid = cursor.fetchone()[0] + 1
#            #enters job info
#            cursor.execute("INSERT INTO priorjobs (PjobID, PJCompanyName, PJJobTitle, PJDuties, PJCity, PJStateID, PJStartDate, PJEndDate, ResumeID) VALUES \
#            (%s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, job['PJCompanyName'], job['PJJobTitle'], job['PJDuties'], job['PJCity'], job['PJStateID'], job['PJStartDate'], job['PJEndDate'], rid])
#
 #   #-----EDUCATION UPDATE------
#    #gets a list of education IDs that should belong to this resume
#    #for edu in education:
#    #    eduList.append(edu['EducationID'])   
#
 #   #gets a list of education IDs that currently belong to this resume in the DB
#    cursor.execute("SELECT EducationID FROM education WHERE ResumeID=%s", [resume['ResumeID']])
#    rv = cursor.fetchall()
#    #formatting because return list is formatted like this: ((1,), (2,), ...)
#    for x in rv:
#        curEdu.append(x[0])
#
 #   eduids = []
#    #list of existing jobs to keep associated with the resume
#    for x in education:
#        if x['EducationID'] is not "":
#            eduids = eduids + x['EducationID']
#
 #   #if it exists in the database, but does not exist in the update info, delete it (database - new list taken in)
#    deletedEdu = set(curEdu) - set(education)
#    #if it exists in the new list, but not the databse, add it
#    #addedEdu = set(education) - set(curEdu)
#
 #   #updates education
#    for edu in education:
#        #if the ID for this dict is in the list to delete, delete the row
#        if edu['EducationID'] in deletedEdu:
#            cursor.execute("DELETE FROM education WHERE EducationID=%s", [edu['EducationID']])
#        #if the ID for this dict is in the list to add, add the row
#        elif edu['EducationID'] == '':
#            #gets ID of university from given name
#            cursor.execute("SELECT UniversityID FROM university WHERE UniversityName=%s", [edu['UniversityName']])
#            uid = cursor.fetchone()
#            #if the university doesn't already exist, enter it
#            if not uid:
#                cursor.execute("SELECT MAX(UniversityID) FROM university")
#                uid = cursor.fetchone()[0] + 1
#                #enters new university if needed
#                cursor.execute("INSERT INTO university (UniversityID, UniverstyName) VALUES (%s, %s)", [uid, edu['UniversityName']])
#            else:
#                uid = uid[0]
#            #makes a unique educationID
#            cursor.execute("SELECT MAX(EducationID) FROM education")
#            eid = cursor.fetchone()[0] + 1
#            #enters education info
#            cursor.execute("INSERT INTO education (EducationID, EUniversityID, EGPA, EstartDate, EGradDate, DegreeTypeID, DegreeAreaID, ResumeID) VALUES \
#            (%s, %s, %s, %s, %s, %s, %s, %s)", [eid, uid, edu['EGPA'], edu['EstartDate'], edu['EGradDate'], edu['DegreeTypeID'], edu['DegreeAreaID'], rid])
#

#-----ADD RESUME-----
#assumes that the dict has three things: resume info, education dict list, skill dict list, priorJobs
def addResume(resumedict, education, priorjobs, skillset, resumefile):
    cursor = connection.cursor()
    cursor.execute("SELECT MAX(ResumeID) FROM resume")
    #gets a unique resume ID
    rid = cursor.fetchone()
    rid = rid[0] + 1

    #adds resume info in resume table if there is one
    if resumefile:
        #gets file as bytes and filename
        f = resumefile.read()
        fname = resumefile.name

        #adds resume info in resume table
        cursor.execute("INSERT INTO resume (ResumeID, ROBjective, RSalaryMin, RFile, UName, RName, RFilename) VALUES \
        (%s, %s, %s, %s, %s, %s, %s)", [rid, resumedict['RObjective'], resumedict['RSalaryMin'], f, resumedict['UName'], resumedict['RName'], fname])
    else:
         #adds resume info in resume table
        cursor.execute("INSERT INTO resume (ResumeID, ROBjective, RSalaryMin, UName, RName) VALUES \
        (%s, %s, %s, %s, %s)", [rid, resumedict['RObjective'], resumedict['RSalaryMin'], resumedict['UName'], resumedict['RName']])

    #adds skills for resume
    for skill in skillset:
        cursor.execute("INSERT INTO skillset (SSkillID, ResumeID) VALUES (%s, %s)", [skill, rid])

    #adds education for resume
    for edu in education:
        #gets ID of university from given name
        cursor.execute("SELECT UniversityID FROM university WHERE UniversityName=%s", [edu['UniversityName']])
        uid = cursor.fetchone()
        #if the university doesn't already exist, enter it
        if not uid:
            cursor.execute("SELECT MAX(UniversityID) FROM university")
            uid = cursor.fetchone()[0] + 1

            cursor.execute("INSERT INTO university (UniversityID, UniversityName) VALUES (%s, %s)", [uid, edu['UniversityName']])
        else:
            uid = uid[0]

        #makes a unique educationID
        cursor.execute("SELECT MAX(EducationID) FROM education")
        eid = cursor.fetchone()[0] + 1
        #enters education info
        cursor.execute("INSERT INTO education (EducationID, EUniversityID, EGPA, EstartDate, EGradDate, DegreeTypeID, DegreeAreaID, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s)", [eid, uid, edu['EGPA'], edu['EstartDate'], edu['EGradDate'], edu['DegreeTypeID'], edu['DegreeAreaID'], rid])

    #adds prior jobs for resume
    for job in priorjobs:
        #makes a unique priorJobID
        cursor.execute("SELECT MAX(PjobID) FROM priorjobs")
        jid = cursor.fetchone()[0] + 1
        #enters job info
        cursor.execute("INSERT INTO priorjobs (PjobID, PJCompanyName, PJJobTitle, PJDuties, PJCity, StateID, PJStartDate, PJEndDate, ResumeID) VALUES \
        (%s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, job['PJCompanyName'], job['PJJobTitle'], job['PJDuties'], job['PJCity'], job['StateID'], job['PJStartDate'], job['PJEndDate'], rid])

#Probably no necessary at all, but made them just in case (would have been to simplify viewResume)
#def getEducationDetails(resumeid):
#    cursor = connection.cursor()
#    #gets id, university name, gpa, start/grad dates, degree type/area for all education entires for given resume
#    cursor.exectue("SELECT EducationID, UniversityName, EGPA, EstartDate, EGradDate, DegreeType, DegreeArea FROM education, degreetype, degreearea, university WHERE \
#    EUniversityID=UniversityID AND education.DegreeTypeID=degreetype.DegreeTypeID AND education.DegreeAreaID=degreearea.DegreeAreaID AND ResumeID=%s", [resumeid])
#    
#    edu = dictfetchall(cursor)#

#    return edu#

#def getPriorJobDetails(resumeid):
#    cursor = connection.cursor()
#    #gets id, company name, job title, duties, city, state abbreviation, start/end dates for all prior job entries for a given resume
#    cursor.exectue("SELECT PjobID, PJCompanyName, PJJobTitle, PJDuties, PJCity, Abbr, PJStartDate, PJEndDate FROM priorjobs, state WHERE state.stateID=priorjobs.StateID AND ResumeID=%s", [resumeid])#

#    pjobs = dictfetchall(cursor)#

#    return pjobs
