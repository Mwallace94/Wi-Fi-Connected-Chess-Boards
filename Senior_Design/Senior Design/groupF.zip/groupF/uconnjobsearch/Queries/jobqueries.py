#query to view job details
from __future__ import unicode_literals

from django.db import connection
from django.db import IntegrityError
import time

def dictfetchall(cursor):
    #"Returns all rows from a cursor as a dict"
    desc = cursor.description
    return [
        dict(zip([col[0] for col in desc], row))
        for row in cursor.fetchall()
    ]

#all info used in details for poster, shared function with job application details, but no fill status
#NEEDS TESTING AS A WHOLE
#returns a dict with a job dict, list of skill dicts, list of degree types, and list of degree areas
def viewJob(jid):
    cursor = connection.cursor()

    #gets basic job info from job table
    cursor.execute("SELECT JobID,JListDate,JobTitle,JCity,Abbr,Zipcode,JDuties,JYRSExperience,JLowRange,JHighRange,JFillStatus,CName \
    FROM job,state WHERE state.stateID=job.StateID AND JobID=%s", [jid])
    details = dictfetchall(cursor)

    #gets list of degree areas for this job (list of strings)
    cursor.execute("SELECT DegreeArea from degreearea WHERE DegreeAreaID IN (SELECT DegreeAreaID FROM job_degreearea WHERE JobID=%s)", [jid])
    degreeAreas = cursor.fetchall()

    #gets list of degree types for this job
    cursor.execute("SELECT DegreeType from degreetype WHERE DegreeTypeID IN (SELECT DegreeTypeID FROM job_degreetype WHERE JobID=%s)", [jid])
    degreeTypes = cursor.fetchall()

    #gets a list of skills for a job (names only)
    cursor.execute("SELECT SSkillName FROM skill WHERE skill.SSkillID IN (SELECT SSkillID FROM job_skills WHERE JobID=%s);", [jid])
    skillList = cursor.fetchall()

    #details.update(job_degreearea = degreeAreas, job_degreetype = degreeTypes, job_skills = skillList)
    rv = { 'job': details[0], 'job_degreearea': degreeAreas, 'job_degreetype': degreeTypes, 'job_skills': skillList }

    return rv

#user applies for a job with a specific resume
#returns an error message if the user had already applied for the job
def applyForJob(uname, jobid, resumeid):
    #current time as a string in mm/dd/yyyy format
    curdate = time.strftime("%m/%d/%Y")

    cursor = connection.cursor()
    try:
        cursor.execute("INSERT INTO applies (JobID, UName, DateApplied, ResumeID) VALUES (%s, %s, %s, %s)", [jobid, uname, curdate, resumeid])
    except IntegrityError:
        return "Already applied for this job."

#for job search; just use details from poster's details for job details
#jobID, company name, job title, salary min/max, list date for jobs searched by title that are not already filled
def getJobs(title):
    cursor = connection.cursor()
    #gets all unfilled jobs with a title that contains the string searched for
    cursor.execute("SELECT JobID, CName, JobTitle, JLowRange, JHighRange, JListDate, JFillStatus FROM job WHERE JobTitle LIKE %s AND JFillStatus='No'", ["%" + title + "%"])

    jobs = dictfetchall(cursor)

    return jobs

#expects job dict, degree area id, degree type id (use dropdown menus for these options), list of skill IDs
#may not be up to spec, need to check
#job contains title, city, state id, zip, duties, years exp, low, high, company name
#list of numbers for degree area, degree type, skills
def postJob(job, degreearea, degreetype, skills, uname):
    #current time as a string in mm/dd/yyyy format
    curdate = time.strftime("%m/%d/%Y")

    cursor = connection.cursor()
    #generates a unique job id
    cursor.execute("SELECT MAX(JobID) FROM job")
    jid = cursor.fetchone()[0] + 1

    cursor.execute("INSERT INTO job (JobID, JListDate, JobTitle, JCity, StateID, Zipcode, JDuties, JYRSExperience, JLowRange, JHighRange, JFillStatus, CName) VALUES \
    (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", [jid, curdate, job['JobTitle'], job['JCity'], job['StateID'], job['Zipcode'], job['JDuties'], job['JYRSExperience'], job['JLowRange'], job['JHighRange'], "No", job['CName']])
    
    #adds all skills for job
    for skill in skills:
       cursor.execute("INSERT INTO job_skills (SSkillID, JobID) VALUES (%s, %s)", [skill, jid])

    #adds all degree types for job
    for degtype in degreetype:
        cursor.execute("INSERT INTO job_degreetype (DegreeTypeID, JobID) VALUES (%s, %s)", [degtype, jid])

    #adds all degree areas for job
    for degarea in degreearea:
        cursor.execute("INSERT INTO job_degreearea (DegreeAreaID, JobID) VALUES (%s, %s)", [degarea, jid])

    cursor.execute("INSERT INTO posts (JobID, UName) VALUES (%s, %s)", [jid, uname])

    return jid

#gets job title, resumeid, company name, and job id for all jobs that a user has applied for
def getJobsAppliedFor(uname):
    cursor = connection.cursor()
    #gets job title, company name, and job id for jobs applied for
    cursor.execute("SELECT JobTitle, CName, JobID FROM job WHERE job.JobID IN (SELECT JobID FROM applies WHERE UName=%s)", [uname]);
    jobs = dictfetchall(cursor)

    for job in jobs:
        #gets resumeID for this job and adds it to the dict
        cursor.execute("SELECT ResumeID FROM applies WHERE UName=%s AND JobID=%s", [uname, job['JobID']])
        rid = cursor.fetchone()[0]
        job.update({'ResumeID':rid})

    return jobs

#gets all of a user's posted jobs (database assumes each user can only post for one company, but not necessarily vice versa)
def getPostedJobs(uname):
    cursor = connection.cursor()
    #gets job title and id for a poster
    #cursor.execute("SELECT JobID, JobTitle FROM job WHERE job.CName=(SELECT CName FROM poster WHERE UName=%s)", [uname])
    cursor.execute("SELECT JobID, JobTitle, JFillStatus FROM job WHERE job.JobID IN (SELECT JobID from posts WHERE UName=%s)", [uname])
    jobs = dictfetchall(cursor)

    return jobs

    #query for addition of posts table
    #SELECT JobID, JobTitle FROM job WHERE job.JobID IN (SELECT JobID from posts WHERE UName=uname)

    #returns details about a job for a given job id (meant to be used by poster and by job search function on apply page)

#switches the job's fill status to the other fill status
def changeFilledStatus(jid):
    cursor = connection.cursor()
    #updates job status based on what the status was
    cursor.execute("SELECT JFillStatus FROM job WHERE JobID=%s", [jid])
    status = cursor.fetchone()

    if status[0] == 'Yes':
        cursor.execute("UPDATE job SET JFillStatus='No' WHERE JobID=%s", [jid])
    else:
        cursor.execute("UPDATE job SET JFillStatus='Yes' WHERE JobID=%s", [jid])

#deletes a job (and its skills, applicants, and posts entry)
def deleteJob(jobid):
    cursor = connection.cursor()
    #removes all skills for the job
    cursor.execute("DELETE FROM job_skills WHERE JobID=%s", [jobid])
    #deletes all applications for the job
    cursor.execute("DELETE FROM applies WHERE JobID=%s", [jobid])
    #deletes from the posts table
    cursor.execute("DELETE FROM posts WHERE JobID=%s", [jobid])
    #finally, deletes the job entry
    cursor.execute("DELETE FROM job WHERE JobID=%s", [jobid])

#remove's a user's application for a job
def deleteApp(uname, jobid):
    cursor = connection.cursor()
    #removes application entry
    cursor.execute("DELETE FROM applies WHERE UName=%s AND JobID=%s", [uname, jobid])

def hasPosted(uname, jobid):
    cursor = connection.cursor()
    #checks if the user posted the job
    cursor.execute("SELECT UName FROM posts WHERE UName=%s AND JobID=%s", [uname, jobid])
    rv = cursor.fetchone()

    if rv:
        return True
    else:
        return False
