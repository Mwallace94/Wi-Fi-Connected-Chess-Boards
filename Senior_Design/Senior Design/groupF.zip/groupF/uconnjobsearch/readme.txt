-for database connection information, see the uconnjobsearch/settings.py file. The only fields you should need to change are NAME (the database name), USER (the databse user), and PASSWORD. No other settings in this file need to be changed.
-the database dump to use is db.sql in the main directory of the project

Download and install Python3 (https://www.python.org/ftp/python/3.4.3/python-3.4.3.msi), Python2 will NOT work for this project.
-if you choose to edit the install options be sure to leave install pip selected

Assuming you used the default install directory of C:/python34, open a command prompt and enter the following:
C:\Python34\Scripts\pip.exe install django
C:\Python34\Scripts\pip.exe install mysqlclient
This will install both of the necessary libraries to run our project.

Now navigate to where you extracted our project to
(ex: cd C:\Users\Mark\Downloads\uconnjobsearch\)
and run 'C:\Python34\python.exe manage.py runserver 80'
*Note: you must have a mysql server running (configured to match whats in settings.py) for this to work.

This runs a minimal python-based webserver that will serve our application.
Note that in the above statement, 80 is the port number for the server to listen on.
If you are running XAMP, you might want to change the port in order to avoid conflicts.