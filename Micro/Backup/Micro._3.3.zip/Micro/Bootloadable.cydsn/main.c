#include "main.h"


int main() {
    
    init();
    
    while(1) {

        debug();
        
    }
}


/*
int main() {
    
    init();
    
    CyDelay(1000);
    
    Esp_UART_PutString("AT\n\n");
    
    while(1) {

        if(Debug_UART_GetRxBufferSize() > 0) {
            char temp = Debug_UART_GetChar();
            Esp_UART_PutChar(temp);
            if(temp == '\r') Esp_UART_PutChar('\n');
        }
        if(Esp_UART_GetRxBufferSize() > 0) {
            Debug_UART_PutChar(Esp_UART_GetChar());
        }
        
    }
}
*/

void init() {
    CyGlobalIntEnable;
    
    Debug_UART_Start();
    Debug_UART_PutString("CSE 4940: Wireless Chess Board\r\n\r\n");
    
    Esp_UART_Start();
    
    LCD_Start();
}

void debug() {

    char message[64] = "";
    char temp;
    char length;
    
    extern int16 x_pos;
    extern int16 y_pos;
    
    char buffer[6] = "";

    if(Debug_UART_GetRxBufferSize() > 0) {

        for(int i = 0; (temp = Debug_UART_GetChar()) != '\r'; i++) {
            Debug_UART_PutChar(temp);
            message[i] = temp;
            while(Debug_UART_GetRxBufferSize() == 0);
        }
        
        Debug_UART_PutString("\r\n");
        Debug_UART_ClearRxBuffer();

        length = strlen(message);

        char num[16] = "";
        switch(message[0]) {
            case 'x':
                if(length > 3) {
                    for(int i = 3; i < length; i++) {
                        num[i - 3] = message[i];
                    }
                    if(message[2] == '-') {
                        move_x((int16) (atoi(num)*-1));
                    } else {
                        move_x((int16) (atoi(num)));
                    }
                    Debug_UART_PutString("moving x\r\n\r\n");
                }
                break;
            case 'y' :
                if(length > 3) {
                    for(int i = 3; i < length; i++) {
                        num[i - 3] = message[i];
                    }
                    if(message[2] == '-') {
                        move_y((int16) (atoi(num)*-1));
                    } else {
                        move_y((int16) (atoi(num)));
                    }
                    Debug_UART_PutString("moving y\r\n\r\n");
                }
                break;
            case 'h':
                move_home();
                Debug_UART_PutString("moving home\r\n\r\n");
                break;
            case 'e':
                if(message[2] == 'o' && message[3] == 'n') {
                    Em_Write(1);
                    Debug_UART_PutString("magnet now on\r\n\r\n");
                } else {
                    Em_Write(0);
                    Debug_UART_PutString("magnet now off\r\n\r\n");
                }
                break;
            case 'r':
                read_reed_switches();
                for(int i = 0; i < 8; i++) {
                    for(int j = 0; j < 12; j++) {
                        char on[4] = "";
                        on[0] = on[2] = ' ';
                        on[1] = board[i][j] + 48;
                        Debug_UART_PutString(on);
                    }
                    Debug_UART_PutString("\r\n\r\n");
                }
                break;
            case 'l':
                Debug_UART_PutChar((char) (Lim_1_Read() + 65));
                Debug_UART_PutString(" ");
                Debug_UART_PutChar((char) (Lim_2_Read() + 65));
                Debug_UART_PutString("\r\n\r\n");
                break;
            case 'w':
                Debug_UART_PutString(esp_transmit(".connect", "8"));
                Debug_UART_PutString(esp_transmit(".ready", "6"));
                Debug_UART_PutString(esp_transmit(".gib", "4"));
                Debug_UART_PutString(esp_transmit(".gib", "4"));
                break;
            case 't':
                move.fromCol = col_square;
                move.fromRow = row_square;    
                move.toCol = atoi(message + 3);
                move.toRow = atoi(message + 1);
                movepiece(move);
                break;
            case 'g':
                game();
                break;
            case 'p':
                Debug_UART_PutString("X = ");
                Debug_UART_PutString(itoa(x_pos, buffer, 10));
                Debug_UART_PutString(", Y = ");
                Debug_UART_PutString(itoa(y_pos, buffer, 10));
                Debug_UART_PutString("\r\n\r\n");
            default:
                break;
        }
    }
    
}