/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE 
    void esp_read(char* msg) {
        
    }
    
    char* esp_write() {
        uint8 size = Esp_UART_GetRxBufferSize();
        char msg[size];
        
        for(int i = 0; i < size; i++) {
            msg[i] = Esp_UART_GetChar();
        }
            
        return msg;
    }
        
*/