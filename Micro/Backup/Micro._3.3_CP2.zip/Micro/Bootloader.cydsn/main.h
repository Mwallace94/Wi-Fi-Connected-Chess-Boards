#ifndef MAIN_H
#define MAIN_H
    
#include <stdlib.h>
#include <project.h>
#include "board.h"
    
void init();

void debug();
    
#endif  
